﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rogin : MonoBehaviour {
	public void OnClick() {
		
		Application.LoadLevel ("Rogin");
	}
}
